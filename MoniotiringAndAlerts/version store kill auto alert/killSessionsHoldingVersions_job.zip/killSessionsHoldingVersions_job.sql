USE [msdb]
GO

DECLARE @jobId BINARY(16)
DECLARE @job_name nvarchar(128)
SET @job_name = N'Kill Sessions Holding Version Store'
DECLARE @Database nvarchar(max) = N'WMSPROD01'
DECLARE @Description nvarchar(512) = N'Kill sessions for '+@Database +' with long held active snapshots (DMV) records, when a large version store size is detected'

IF EXISTS (SELECT NULL FROM msdb.dbo.sysjobs WHERE name = @job_name)
	EXEC msdb.dbo.sp_delete_job @job_name=@job_name, @delete_unused_schedule=0,  @delete_history=0 ;

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

DECLARE @LogDirectory nvarchar(max)
IF SERVERPROPERTY('ProductMajorVersion') IS NOT NULL AND CAST(SERVERPROPERTY('ProductMajorVersion') as int) >= 12
  BEGIN
    SELECT @LogDirectory = [path]
    FROM sys.dm_os_server_diagnostics_log_configurations
  END
ELSE
  BEGIN
    SELECT @LogDirectory = LEFT(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max)),LEN(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max))) - CHARINDEX('\',REVERSE(CAST(SERVERPROPERTY('ErrorLogFileName') AS nvarchar(max)))))
  END
IF @LogDirectory IS NOT NULL AND RIGHT(@LogDirectory,1) = '\'
  BEGIN
    SET @LogDirectory = LEFT(@LogDirectory, LEN(@LogDirectory) - 1)
  END
DECLARE @output_file_name nvarchar(200)
SET @output_file_name = @LogDirectory + '\' + REPLACE(@job_name,' ','') + '_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(DATE))_$(ESCAPE_SQUOTE(TIME)).txt'

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=@job_name, 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=@Description, 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'O&M DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'sessions old active snapshots', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [DBAUtility].[dbo].[KillSessionsHoldingVersions] 
         @VersionStoreThreshold = 5.0 -- in GBs, as excessive version store in tempdb
        ,@ElapsedHoursThreshold = 3.0 -- in Hours, as excessive DMV time holding version records
        ,@recipients = ''DL_OwensMinor_SQLDBA@nttdata.com; Steve.Rich@nttdata.com'' -- notification email
        ;', 
		@database_name=@Database, 
		@output_file_name=@output_file_name,
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily, every morning', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20200917, 
		@active_end_date=99991231, 
		@active_start_time=23000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


