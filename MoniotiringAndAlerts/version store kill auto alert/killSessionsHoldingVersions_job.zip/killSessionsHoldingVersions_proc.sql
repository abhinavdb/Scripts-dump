use DBAUtility
go

IF OBJECT_ID('dbo.KillSessionsHoldingVersions') IS NOT NULL
	DROP PROCEDURE dbo.KillSessionsHoldingVersions
GO

CREATE PROCEDURE dbo.KillSessionsHoldingVersions
(
	 @VersionStoreThreshold float = 5.0	-- in GBs, as excessive version store in tempdb
	,@ElapsedHoursThreshold float = 3.0	-- in Hours, as excessive DMV time holding version records
	,@recipients varchar(max) = 'Steve.Rich@nttdata.com'	-- notification email
)
AS
/**************************************************************************
 srich 9/15/20 - determine sessions holding version store records
				 for excessive time, and when large version store size,
				 kill those sessions
**************************************************************************/
SET NOCOUNT ON
DECLARE @SizeVersionStore float
DECLARE @killCmd varchar(max)
DECLARE @printforLog varchar(max)
DECLARE @logHeader bit = 0
DECLARE @tableHTML  NVARCHAR(MAX)
declare @profile_name sysname = NULL
declare @subject nvarchar(4000)
DECLARE @PostedDate datetime = GETDATE();

DECLARE @session_id smallint
DECLARE @host_name nvarchar(128)
DECLARE @program_name nvarchar(128)
DECLARE @database_name nvarchar(256)
DECLARE @login_time datetime
DECLARE @login_name nvarchar(128)
DECLARE @last_request_end_time datetime
DECLARE @elapsed_time_seconds bigint

DECLARE @sessionsnapshotspastthreshold table (
	 session_id smallint
	,host_name nvarchar(128)
	,program_name nvarchar(128)
	,database_name nvarchar(256)
	,login_time datetime
	,login_name nvarchar(128)
	,last_request_end_time datetime
	,elapsed_time_seconds bigint
	,completed bit )

SELECT @SizeVersionStore = SUM(version_store_reserved_page_count)*8/1024./1024.
FROM tempdb.sys.dm_db_file_space_usage ; 

INSERT INTO @sessionsnapshotspastthreshold
	select DISTINCT
		 ses.session_id, ses.host_name, ses.program_name
		,db_name(ses.database_id) as database_name 
		,ses.login_time, ses.login_name, ses.last_request_end_time
		,elapsed_time_seconds,  0 as completed
	from sys.dm_exec_sessions ses
	inner join sys.dm_tran_active_snapshot_database_transactions sdt on ses.session_id = sdt.session_id
	where db_name(ses.database_id) = 'WMSPROD01'
	and ses.program_name LIKE 'WMSPROD01%'
	and ses.is_user_process = 1 -- exclude system processes
	and sdt.elapsed_time_seconds/3600. > @ElapsedHoursThreshold ;

-- if both high version store size, and sessions holding version records consistent in the DMV
IF @SizeVersionStore > @VersionStoreThreshold
AND EXISTS (select NULL from @sessionsnapshotspastthreshold)
BEGIN
	WHILE exists (select null from @sessionsnapshotspastthreshold where completed = 0)
		BEGIN
		SELECT TOP(1)
			@session_id  = session_id ,
			@host_name = host_name ,
			@program_name = program_name ,
			@database_name = database_name ,
			@login_time = login_time ,
			@login_name = login_name ,
			@last_request_end_time = last_request_end_time ,
			@elapsed_time_seconds = elapsed_time_seconds
		FROM @sessionsnapshotspastthreshold
		WHERE completed = 0;

		SET @killCmd = 'kill ' + CONVERT(varchar,@session_id) + ';'
		EXEC (@killCmd); 

		-- print session info to job output log
		IF @logHeader = 0
			begin
			set @logHeader = 1
			SET @printforLog =
				 'Killed sessions on '+CONVERT(varchar(100),@PostedDate,100)+' for WMSPROD01, '
				+'that were holding version store records (size= ' + CONVERT(varchar,@SizeVersionStore) +' GB), '
				+'and with snapshot threshold longer than ' +CONVERT(varchar,@ElapsedHoursThreshold) + ' hours'
			PRINT @printforLog ;
			end
		SET @printforLog = 
			'   '+CONVERT(nvarchar(5),@session_id)+': '
			+SUBSTRING(@database_name,1,35)+'|'+SUBSTRING(@host_name,1,35)+'|'+SUBSTRING(@program_name,1,35)
			+'  ... '
			+'Login name='+@login_name+',time='+CONVERT(varchar,@login_time,120)
			+' ... '
			+'Last batch='+CONVERT(varchar,@last_request_end_time,120)
			+' ... '
			+'Elapsed seconds in DMV='+CONVERT(varchar,@elapsed_time_seconds)
		PRINT @printforLog ;
	
		UPDATE @sessionsnapshotspastthreshold
		SET completed = 1
		WHERE session_id = @session_id ;
		END -- end loop to kill sessions, but also post in output log

	--------------------------------
	-- report for notification
	--------------------------------
	-- setup the email notication body; header first
	SET @tableHTML =
		  N'<html>'
		+ N'<head>' 
		+ N'<style>td {border: solid black;border-width: 1px;padding-left:5px;padding-right:5px;padding-top:1px;padding-bottom:1px;font: 11px calibri}</style>'
		+ N'</head>' 
		+ N'<body>Killed sessions on '+CONVERT(varchar(100),@PostedDate,100)+' for WMSPROD01,'
		+ N'<br>that were holding version store records (size= ' + CONVERT(varchar,@SizeVersionStore) +' GB), '
		+ N'<br>and with snapshot threshold longer than ' +CONVERT(varchar,@ElapsedHoursThreshold) + ' hours'
		+ N'<br>'
		+ N'<br>'
	-- second, the killed sessions ... 
	SET @tableHTML = @tableHTML +
		N'<table cellpadding=0 cellspacing=0 border=0>' +  
		N'<col width="500px" />' +
		N'<tr>' +
		N'<td bgcolor=#E6E6FA><b>spid</b></td>' +
		N'<td bgcolor=#E6E6FA><b>hostname</b></td>' +
		N'<td bgcolor=#E6E6FA><b>database</b></td>' +
		N'<td bgcolor=#E6E6FA><b>program_name</b></td>' +
		N'<td bgcolor=#E6E6FA><b>loginame</b></td>' +
		N'<td bgcolor=#E6E6FA><b>login_time</b></td>' +
		N'<td bgcolor=#E6E6FA><b>last_batch</b></td>' +
		N'<td bgcolor=#E6E6FA><b>elapsed_time_seconds</b></td>' +
		N'</tr>' +  
		CAST ( ( 
			SELECT
				td=COALESCE(CONVERT(nvarchar(5),[session_id]),''),'',td=COALESCE([host_name],''),'',td=COALESCE([database_name],''),'',
				td=COALESCE([program_name],''),'',td=COALESCE([login_name],''),'',td=COALESCE([login_time],''),'',
				td=COALESCE([last_request_end_time],''),'',td=COALESCE([elapsed_time_seconds],''),''
			FROM @sessionsnapshotspastthreshold
			FOR XML PATH('tr'), TYPE   
		) AS NVARCHAR(MAX) ) +  
		N'</table>' +
		N'<br>' ;
	-- last, cap the end of email body & html page
	SET @tableHTML = @tableHTML + N'</body>' + N'</html>'

	-- retrieve profile name for notification email
	SELECT TOP(1) @profile_name = p.name
		FROM msdb.dbo.sysmail_profile p 
		LEFT OUTER JOIN msdb.dbo.sysmail_principalprofile pp ON pp.profile_id = p.profile_id
		WHERE pp.profile_id IS NULL OR pp.principal_sid = 0x00 OR SUSER_SNAME(pp.principal_sid) = SUSER_SNAME()
		ORDER BY 
			CASE
				WHEN @@SERVERNAME LIKE ('%'+p.name+'%') THEN 1				-- profiles specifically named after server/instance
				WHEN pp.principal_sid = 0x00 AND pp.is_default = 1 THEN 2	-- default public profile
				WHEN pp.principal_sid = 0x00 THEN 3							-- other public profiles
				WHEN pp.principal_sid IS NULL THEN 4							-- disabled profile, but still a public profile
				WHEN pp.principal_sid <> 0x00 AND SUSER_SNAME(principal_sid) = SUSER_SNAME() THEN 5	-- private profile and same as the calling user
			END, p.name;

	-- setup and then send email notification
	IF @profile_name IS NOT NULL
		BEGIN
		SET @subject = SUBSTRING((@@SERVERNAME + ' - Killed sessions holding version store records'),1,255) -- length for dbmail subject line
		EXEC msdb.dbo.sp_send_dbmail
			@profile_name = @profile_name,
			@recipients = @recipients,
			@subject = @subject,
			@body = @tableHTML,  
			@body_format = 'HTML' ; 
		END;
END -- end process to kill when over thresholds

FINI:
GO